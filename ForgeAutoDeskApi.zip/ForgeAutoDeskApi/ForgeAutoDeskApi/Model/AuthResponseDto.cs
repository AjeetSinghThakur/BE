﻿using Newtonsoft.Json;

namespace ForgeAutoDeskApi.Model {
    public class AuthResponseDto {
        [JsonProperty("token_type")]
        public string tokenType = null!;

        [JsonProperty("expires_in")]
        public int expires_in;

        [JsonProperty("access_token")]
        public string accessToken = null!;
    }
}
