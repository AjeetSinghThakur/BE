﻿using Autodesk.Forge;
using Autodesk.Forge.Model;
using ForgeAutoDeskApi.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Text.RegularExpressions;

namespace ForgeAutoDeskApi.Controllers {
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase {

        private static readonly string FORGE_CLIENT_ID = "OvoOocPUt3yExQDLzDRzeqydnLnoMr4A";
        private static readonly string FORGE_CLIENT_SECRET = "N2BFr1iSDpcEkpnz";

        [AllowAnonymous]
        [HttpGet("")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<string>> Translate() {

            string bucketKey = "forgeapp" + Guid.NewGuid().ToString("N").ToLower();
            string fileSavePath = "d://myfiles//1343939490.dwg";

            var scope = new Scope[] { Scope.BucketCreate, Scope.DataCreate, Scope.DataWrite, Scope.DataRead };
           
            TwoLeggedApi twoLeggedApiClient = new();
           
            // get a write enabled token
            TwoLeggedApi oauthApi = new();
            var forgerAuthResponse = await twoLeggedApiClient.AuthenticateAsyncWithHttpInfo(FORGE_CLIENT_ID,
                FORGE_CLIENT_SECRET, oAuthConstants.CLIENT_CREDENTIALS, scope);

            AuthResponseDto bearer = JsonConvert.DeserializeObject<AuthResponseDto>(
                Convert.ToString(forgerAuthResponse.Data));

            // create the Forge bucket
            PostBucketsPayload postBucket = new(bucketKey, null, PostBucketsPayload.PolicyKeyEnum.Transient /* erase after 24h*/ );
            BucketsApi bucketsApi = new();
            bucketsApi.Configuration.AccessToken = bearer.accessToken;
            dynamic newBucket = await bucketsApi.CreateBucketAsync(postBucket);

            // upload file (a.k.a. Objects)
            ObjectsApi objectsApi = new();
            oauthApi.Configuration.AccessToken = bearer.accessToken;
            dynamic newObject;
            using (StreamReader fileStream = new StreamReader(fileSavePath)) {
                newObject = await objectsApi.UploadObjectAsync(bucketKey, Path.GetFileName(fileSavePath),
                    (int)fileStream.BaseStream.Length, fileStream.BaseStream,
                    "application/octet-stream");
            }
            var plainTextBytes = System.Text.Encoding.UTF8.GetBytes(newObject.objectId);
            var objectIdBase64 = Convert.ToBase64String(plainTextBytes);

            List<JobPayloadItem> postTranslationOutput = new List<JobPayloadItem>()
            {
                new JobPayloadItem(
                JobPayloadItem.TypeEnum.Svf,
                new List<JobPayloadItem.ViewsEnum>()
                {
                   JobPayloadItem.ViewsEnum._3d,
                   JobPayloadItem.ViewsEnum._2d
                })
            };

            JobPayload postTranslation = new(
                new JobPayloadInput(objectIdBase64),
                new JobPayloadOutput(postTranslationOutput));
            
            DerivativesApi derivativeApi = new();
            derivativeApi.Configuration.AccessToken = bearer.accessToken;
            _ = await derivativeApi.TranslateAsync(postTranslation);

            // check if is ready
            int progress = 0;
            do {
                System.Threading.Thread.Sleep(1000);
                try {
                    dynamic manifest = await derivativeApi.GetManifestAsync(objectIdBase64);
                    progress = (string.IsNullOrWhiteSpace(Regex.Match(manifest.progress, @"\d+").Value) ?
                        100 : Int32.Parse(Regex.Match(manifest.progress, @"\d+").Value));
                } catch (Exception ex) {
                    Console.WriteLine(ex.Message);
                }
            } while (progress < 100);

            return Ok(objectIdBase64);
        }
    }
}
